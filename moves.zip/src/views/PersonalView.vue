<template>
  <div>
    <div v-for="(item, index) in data" :key="index">
      <div class="img-box">
        <img :src="item.url" alt="" class="img" />
        <div class="mssager">
          <div class="title">{{ item.title }}</div>
          <div class="desc">{{ item.desc }}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { reactive, toRefs } from "vue";
export default {
  setup() {
    let data = [
      {
        url: require("../assets/images/4.jpeg"),
        title: "生活/03'09",
        desc: "美丽的风景需要有发现美的眼睛",
        id: 1,
      },
      {
        url: require("../assets/images/5.jpeg"),
        title: "生活/03'14",
        desc: "美丽的风景需要有发现美的眼睛",
        id: 2,
      },
      {
        url: require("../assets/images/1.jpeg"),
        title: "生活/04'31",
        desc: "美丽的风景需要有发现美的眼睛",
        id: 3,
      },
    ];
    return {
      data,
    };
  },
};
</script>

<style lang="scss" scoped>
.img-box {
  position: relative;
  height: 300px;
  .img {
    height: 100%;
    // display: block;
    // vertical-align: top;
  }
  .mssager {
    position: absolute;
    bottom: 20px;
    left: 20px;

    .title {
      color: #999;
      font-size: 14px;
      margin-bottom: 10px;
    }
    .desc {
      color: #fff;
      font-size: 18px;
      font-weight: bold;
    }
  }
}
</style>