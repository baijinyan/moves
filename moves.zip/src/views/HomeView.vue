<template>
  <div class="home">
    <Nav class="nav" />
    <router-view />
  </div>
</template>

<script>
import Nav from "@/components/Nav.vue";

export default {
  name: "HomeView",
  components: {
    Nav,
  },
};
</script>
<style lang="scss" scoped>
.home {
  max-width: 375px;
  min-height: 100vh;
}
.nav {
  position: sticky;
  top: 0;
  z-index: 999;
}
</style>
