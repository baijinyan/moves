import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView,
    // 定义二级路由
    children:[
      {
        path: '/about',
        name: 'about',
    
        component: () => import('../views/AboutView.vue')
      },
      {
        path: '/personal',
        name: 'personal',
    
        component: () => import('../views/PersonalView.vue')
      },
      {
        path: '/find',
        name: 'find',
    
        component: () => import('../views/FindView.vue')
      }
  ]
  },
 

]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
