<template>
  <nav>
    <!-- <router-link to="/">Home</router-link> |
    <router-link to="/about">About</router-link> -->
  </nav>
  <router-view />
</template>

<style lang="scss">
@font-face {
  font-family: "icomoon";
  src: url("./assets/fonts/icomoon.eot?fh0gd1");
  src: url("./assets/fonts/icomoon.eot?fh0gd1#iefix")
      format("embedded-opentype"),
    url("./assets/fonts/icomoon.ttf?fh0gd1") format("truetype"),
    url("./assets/fonts/icomoon.woff?fh0gd1") format("woff"),
    url("./assets/fonts/icomoon.svg?fh0gd1#icomoon") format("svg");
  font-weight: normal;
  font-style: normal;
  font-display: block;
}
* {
  padding: 0;

  margin: 0;
}
</style>
