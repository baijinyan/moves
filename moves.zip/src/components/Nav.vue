<template>
  <div class="nav">
    <div class="heard-box">
      <div class="left"></div>
      <div
        v-for="(item, index) in data"
        :key="index"
        @click="change(item, index)"
      >
        <router-link :to="item.path">
          <div :class="count == index ? 'heard active' : 'heard'">
            {{ item.title }}
          </div>
        </router-link>
      </div>
      <div class="right"></div>
    </div>
  </div>
</template>

<script>
// 引入响应式的方法
import { reactive, toRefs } from "vue";
export default {
  name: "Nav",
  setup() {
    // 定义响应式的属性
    let obj = reactive({
      count: 0,
    });
    let data = [
      {
        title: "发现",
        path: "/find",
        id: 1,
      },
      {
        title: "频道",
        path: "/about",
        id: 2,
      },
      {
        title: "我的",
        path: "/personal",
        id: 3,
      },
    ];

    let change = (v, i) => {
      // 比较自定义的数值是否等于传入的下标
      // 相等则终止后续的代码执行 防止用户重复点击
      if (obj.count === i) {
        return;
      }
      // 不相等则将下标进行赋值 动态渲染样式
      obj.count = i;
    };
    return {
      // 定义响应式的值
      ...toRefs(obj),
      data,
      change,
    };
  },
};
</script>

<style scoped lang="scss">
.nav {
  .heard-box {
    height: 50px;
    color: #fff;
    font-size: 14px;
    // background-image: linear-gradient(
    //   to top,
    //   rgba(255, 255, 255, 1),
    //   rgba(0, 0, 0, 1) 30px
    // );
    background-color: #000;
    display: flex;
    justify-content: space-around;
    align-items: center;

    .left::before {
      font-family: "icomoon";
      content: "\e953";
    }
    .heard {
      height: 50px;
      color: #999;
      line-height: 50px;
    }
    .right::after {
      font-family: "icomoon";
      content: "\e986";
    }
  }
  .active {
    color: #fff !important;
    font-weight: bold;
    border-bottom: 3px solid #fff;
    box-sizing: border-box;
  }
}
</style>
